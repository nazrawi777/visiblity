(function ($) {
 "use strict";

	/*--
		Bootstrap Dropdown Animation
	-----------------------------------*/
	// Add slideDown animation to Bootstrap dropdown when expanding.
	$('.dropdown').on('show.bs.dropdown', function() {
		$(this).find('.dropdown-menu').first().stop(true, true).slideDown();
	});

	// Add slideUp animation to Bootstrap dropdown when collapsing.
	$('.dropdown').on('hide.bs.dropdown', function() {
		$(this).find('.dropdown-menu').first().stop(true, true).slideUp();
	});
	
	/*--
		Off Canvas Menu
	-----------------------------------*/

    /*Variables*/
    var $offCanvasNav = $('.offcanvas-menu'),
    $offCanvasNavSubMenu = $offCanvasNav.find('.sub-menu, .mega-sub-menu, .menu-item ');

    /*Add Toggle Button With Off Canvas Sub Menu*/
    $offCanvasNavSubMenu.parent().prepend('<span class="mobile-menu-expand"></span>');

    /*Close Off Canvas Sub Menu*/
    $offCanvasNavSubMenu.slideUp();

    /*Category Sub Menu Toggle*/
    $offCanvasNav.on('click', 'li a, li .mobile-menu-expand, li .menu-title', function(e) {
        var $this = $(this);
        if (($this.parent().attr('class').match(/\b(menu-item-has-children|has-children|has-sub-menu)\b/)) && ($this.attr('href') === '#' || $this.hasClass('mobile-menu-expand'))) {
            e.preventDefault();
            if ($this.siblings('ul:visible').length) {
                $this.parent('li').removeClass('active-expand');
                $this.siblings('ul').slideUp();
            } else {
                $this.parent('li').addClass('active-expand');
                $this.closest('li').siblings('li').find('ul:visible').slideUp();
                $this.closest('li').siblings('li').removeClass('active-expand');
                $this.siblings('ul').slideDown();
            }
        }
    });

    $( ".sub-menu, .mega-sub-menu, .menu-item" ).parent( "li" ).addClass( "menu-item-has-children" );
	
/*------------------------------------
 search option
------------------------------------- */ 
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-tooltip="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})

	
/*------------------------------------
 search option
------------------------------------- */ 
	$('.search-option').hide();
	$(".search-img").on('click', function(){
	   $('.search-option').animate({
		height:'toggle',
	    });
	});
	
/*--------------------------
	Category Accordion
---------------------------- */	
	 $('.rx-parent').on('click', function(){
		$('.rx-child').slideToggle(300);
		$(this).toggleClass('rx-change');
	});
	
/*--------------------------
 collapse
---------------------------- */	
	$('.panel-heading a').on('click', function(){
		$('.panel-heading a').removeClass('active');
		$(this).addClass('active');
	});
	
/*------------------------------------
 nivoSlider active
------------------------------------- */  
	$('#topSlider').nivoSlider({
		effect: 'random',
		slices: 15,
		boxCols: 12,
		boxRows: 4,
		animSpeed: 600,
		pauseTime: 5000,
		startSlide: 0,
		controlNavThumbs: false,
		pauseOnHover: false,
		manualAdvance: false,
		prevText: '',
		nextText: '',
		
	});
	
/*----------------------------
 wow js active
------------------------------ */
 new WOW().init();
	
 
/*----------------------------
  Product Carousel
------------------------------ */  
  $(".product-carousel").owlCarousel({
      autoPlay: false, 
	  slideSpeed:2000,
	  pagination:false,
	  navigation:true,	  
      items : 4,
	  /* transitionStyle : "fade", */    /* [This code for animation ] */
	  navigationText:["<i class='fa fa-caret-left'></i>","<i class='fa fa-caret-right'></i>"],
      itemsDesktop : [1199,4],
	  itemsDesktopSmall : [980,3],
	  itemsTablet: [768,2],
	  itemsMobile : [576,1],
  });
	
	
/*----------------------------
  Product Carousel
------------------------------ */  
  $(".new-product-carousel").owlCarousel({
      autoPlay: false, 
	  slideSpeed:2000,
	  pagination:false,
	  navigation:true,	  
      items : 1,
	  /* transitionStyle : "fade", */    /* [This code for animation ] */
	  navigationText:["<i class='fa fa-caret-left'></i>","<i class='fa fa-caret-right'></i>"],
      itemsDesktop : [1199,1],
	  itemsDesktopSmall : [980,1],
	  itemsTablet: [768,1],
	  itemsMobile : [479,1],
  });
/*----------------------------
  single Product Carousel
------------------------------ */  
  $("#single-product").owlCarousel({
	  autoPlay: false, 
	  slideSpeed:2000,
	  pagination:false,
	  navigation:true,	  
	  items : 3,
	  navigationText:["<i class='fa fa-caret-left'></i>","<i class='fa fa-caret-right'></i>"],
	  itemsDesktop : [1199,3],
	  itemsDesktopSmall : [991, 4],
	  itemsTablet: [767,3],
	  itemsMobile : [0,3],
  });
	
/*----------------------------
 price-slider active
------------------------------ */  
	  $( "#slider-range" ).slider({
	   range: true,
	   min: 88,
	   max: 721,
	   values: [ 88, 721 ],
	   slide: function( event, ui ) {
		$( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
	   }
	  });
	  $( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) +
	   " - $" + $( "#slider-range" ).slider( "values", 1 )); 
	
/*--------------------------
     scrollUp
---------------------------- */
    $.scrollUp({
        scrollText: '<i class="fa fa-angle-up"></i>',
        easingType: 'linear',
        scrollSpeed: 900,
        animation: 'fade'
    });
		
/*----------------------------
  Simple Lence Active
------------------------------ */  
	$('#p-view .simpleLens-lens-image').simpleLens({
	});
	
 
})(jQuery); 